<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/test', function () {
    echo 'asdf';
});


Route::post("get_order","OrderController@get_order");
Route::post("add_order","OrderController@add_order");
Route::post("update_status","OrderController@update_status");
Route::post("signup","UserController@signup");
Route::post("get_otp","UserController@get_otp");
Route::post("verify_otp","UserController@verify_otp");
Route::post("login","UserController@login");
Route::post("change_password","UserController@change_password");
Route::post("check_previous_date","UserController@check_previous_date");
