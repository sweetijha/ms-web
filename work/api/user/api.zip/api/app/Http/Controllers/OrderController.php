<?php

namespace App\Http\Controllers;
//require 'vendor/autoload.php';
use Illuminate\Http\Request;
use DB;
use Intervention\Image\ImageManagerStatic as Image;


class OrderController extends Controller
{
    public function GetOrder(Request $request){

      header("Access-Control-Allow-Origin:*");

    $getorder=DB::table('order_list')->join('user_profile','user_profile.user_id','order_list.order_id')->where('order_list.phone','=','user_profile.phone')->select('*')->get();

    echo json_encode($getorder);

    }

    public function add_order(Request $request){
      header("Access-Control-Allow-Origin:*");
      $date = $request->date;
      $phone = $request->phone;
      $name = $request->name;
      $email = $request->email;
      $shopping_list = $request->shopping_list;
      $status = $request->status;

      $getData = DB::table('order_list')->where('date',$date)->where('phone',$phone)->get();

      if(sizeof($getData)>0){
        $data = [
          "shopping_list" => $shopping_list,
          "status" => $status
        ];
        $insertData = DB::table('order_list')->where('order_id',($getData[0]->order_id))->update($data);
        if($insertData){
          $RESPONSE['error'] = false;
          $RESPONSE['message'] = 'Order Added';
        }else{
          $RESPONSE['error'] = true;
          $RESPONSE['message'] = 'Order Not Added';
        }
      }else{
        $data = array(
          "date" => $date,
          "phone" => $phone,
          "name" => $name,
          "email_id" => $email,
          "shopping_list" => $shopping_list,
          "status" => $status
        );

        $insertData = DB::table('order_list')->insertGetId($data);

        if($insertData){
          $RESPONSE['error'] = false;
          $RESPONSE['message'] = 'Order Added';
        }else{
          $RESPONSE['error'] = true;
          $RESPONSE['message'] = 'Order Not Added';
        }
      }
      return $RESPONSE;
    }
    public function update_status(Request $request){
      header("Access-Control-Allow-Origin:*");
      $order_id = $request->order_id;
      $date = $request->date;
      $shopping_list = $request->shopping_list;
      $status = $request->status;

      $data = [
        "date" => $date,
        "shopping_list" => $shopping_list,
        "status" => $status
      ];

      $insertData = DB::table('order_list')->where('order_id',$order_id)->update($data);

      if($insertData){
        $RESPONSE['error'] = false;
        $RESPONSE['message'] = 'Order Updated';
      }else{
        $RESPONSE['error'] = true;
        $RESPONSE['message'] = 'Order Not Updated';
      }
      return $RESPONSE;
    }

    public function get_order(Request $request){
      header("Access-Control-Allow-Origin:*");
      $date = $request->date;
      $phone = $request->phone;

      

      $getData = DB::table('order_list')->where('date',$date)->where('phone',$phone)->get();

      if(sizeof($getData)>0){
        $RESPONSE['error'] = false;
        $RESPONSE['data'] = $getData[0];
      }else{
        $RESPONSE['error'] = true;
        $RESPONSE['message'] = 'Data not found';
      }
      return $RESPONSE;
    }
}
