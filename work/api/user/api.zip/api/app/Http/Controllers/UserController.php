<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class UserController extends Controller
{
    //
    public function get_otp(Request $request){
      $login_type = $request->type;
      $phone = $request->phone;

      if($login_type == 'signup'){
        $checkPhone = DB::table('user_profile')->where('phone',$phone)->count();
        if($checkPhone>0){
          $RESPONSE['error'] = true;
          $RESPONSE['message'] = 'Phone number already registered.';
        }else{
          $url = 'https://sendotp.msg91.com/api/generateOTP';
          $data = array('countryCode' => '91', 'mobileNumber' => $phone, 'getGeneratedOTP' => true);
          $data_string = json_encode($data);
          $options = array(
              'http' => array(
                  'header'  => ["application-Key: fCr2ocOIrSQ4KK1HoSnzaMDifoyBey8EgUinmEriuk9tcuRIq6TDqxO51KWHpTIPxyZ28BYkWGe2M4M5jPeL84bL8jV3rHhPk_YOYlRY2gs0U_wBnz1AjOcjMay1VbI7rhKX4UuRU6y1SFAisTPzQg==","Content-type: application/x-www-form-urlencoded"],
                  'method'  => 'POST',
                  'content' => $data_string
              )
          );
          $context  = stream_context_create($options);
          $result = file_get_contents($url, false, $context);
          if ($result) {
            $RESPONSE['error'] = false;
            $RESPONSE['message'] = 'OTP has send to your phone number.';
          }else{
            $RESPONSE['error'] = true;
            $RESPONSE['message'] = 'Failed. Try again.';
          }
        }
      }else{
        $checkPhone = DB::table('user_profile')->where('phone',$phone)->count();
        if($checkPhone==0){
          $RESPONSE['error'] = true;
          $RESPONSE['message'] = 'Phone number not registered.';
        }else{
          $url = 'https://sendotp.msg91.com/api/generateOTP';
          $data = array('countryCode' => '91', 'mobileNumber' => $phone, 'getGeneratedOTP' => true);
          $data_string = json_encode($data);
          $options = array(
              'http' => array(
                  'header'  => ["application-Key: fCr2ocOIrSQ4KK1HoSnzaMDifoyBey8EgUinmEriuk9tcuRIq6TDqxO51KWHpTIPxyZ28BYkWGe2M4M5jPeL84bL8jV3rHhPk_YOYlRY2gs0U_wBnz1AjOcjMay1VbI7rhKX4UuRU6y1SFAisTPzQg==","Content-type: application/x-www-form-urlencoded"],
                  'method'  => 'POST',
                  'content' => $data_string
              )
          );
          $context  = stream_context_create($options);
          $result = file_get_contents($url, false, $context);
          if ($result) {
            $RESPONSE['error'] = false;
            $RESPONSE['message'] = 'OTP has send to your phone number.';
          }else{
            $RESPONSE['error'] = true;
            $RESPONSE['message'] = 'Failed. Try again.';
          }
        }
      }
      return $RESPONSE;
    }


    public function verify_otp(Request $request){
      $otp = $request->otp;
      $phone = $request->phone;

      $url = 'https://sendotp.msg91.com/api/verifyOTP';
      $data = array('countryCode' => '91', 'mobileNumber' => $phone, 'oneTimePassword' => $otp);
      $data_string = json_encode($data);
      $options = array(
          'http' => array(
              'header'  => ["application-Key: fCr2ocOIrSQ4KK1HoSnzaMDifoyBey8EgUinmEriuk9tcuRIq6TDqxO51KWHpTIPxyZ28BYkWGe2M4M5jPeL84bL8jV3rHhPk_YOYlRY2gs0U_wBnz1AjOcjMay1VbI7rhKX4UuRU6y1SFAisTPzQg==","Content-type: application/x-www-form-urlencoded"],
              'method'  => 'POST',
              'content' => $data_string
          )
      );
      $context  = stream_context_create($options);
      $result = file_get_contents($url, false, $context);
      if ($result) {
        $RESPONSE['error'] = false;
        $RESPONSE['message'] = 'OTP verify successfully';
      }else{
        $RESPONSE['error'] = true;
        $RESPONSE['message'] = 'Wrong otp';
      }
      return $RESPONSE;
    }

    public function signup(Request $request){
      $name = $request->name;
      $phone = $request->phone;
      $email = $request->email;
      $password = $request->password;

      $checkEmail = DB::table('user_profile')->where('email_id',$email)->count();

      if($checkEmail>0){
        $RESPONSE['error'] = true;
        $RESPONSE['message'] = 'Email ID already register with another account.';
      }else{
        $data = array(
          "name" => $name,
          "phone" => $phone,
          "email_id" => $email,
          "password" => $password
        );
        $result = DB::table('user_profile')->insert($data);
        if ($result) {
          $RESPONSE['error'] = false;
          $RESPONSE['message'] = 'Registration successfully';
        }else{
          $RESPONSE['error'] = true;
          $RESPONSE['message'] = 'Registration failed. Try again.';
        }
      }
      return $RESPONSE;
    }

    public function login(Request $request){
      $phone = $request->phone;
      $password = $request->password;

      $result = DB::table('user_profile')->where('phone',$phone)->where('password',$password)->get();
      if (sizeof($result)>0) {
        $RESPONSE['error'] = false;
        $RESPONSE['message'] = 'Login successful';
        $RESPONSE['data'] = $result[0];
      }else{
        $RESPONSE['error'] = true;
        $RESPONSE['message'] = 'Invalid Credentials';
      }
      return $RESPONSE;
    }

    public function change_password(Request $request){
      $phone = $request->phone;
      $password = $request->password;
      $confirm_password = $request->confirm_password;

      if($password != $confirm_password){
        $RESPONSE['error'] = true;
        $RESPONSE['message'] = 'Password Mismatch';
      }else{
        $data = [
          "password" => $password
        ];
        $result = DB::table('user_profile')->where('phone',$phone)->update($data);
        if (sizeof($result)>0) {
          $RESPONSE['error'] = false;
          $RESPONSE['message'] = 'Password Change Successful';
        }else{
          $RESPONSE['error'] = true;
          $RESPONSE['message'] = 'Password is same as previous one.';
        }
      }

      return $RESPONSE;
    }

}
